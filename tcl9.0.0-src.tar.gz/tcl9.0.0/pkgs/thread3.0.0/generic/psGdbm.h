/*
 * psGdbm.h --
 *
 * See the file "license.txt" for information on usage and redistribution
 * of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 * ---------------------------------------------------------------------------
 */

#ifndef _PSGDBM_H_
#define _PSGDBM_H_

void Sv_RegisterGdbmStore();

#endif /* _PSGDBM_H_ */

/* EOF $RCSfile */

/* Emacs Setup Variables */
/* Local Variables:      */
/* mode: C               */
/* indent-tabs-mode: nil */
/* c-basic-offset: 4     */
/* End:                  */

